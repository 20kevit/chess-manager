#!/usr/bin/env python3
"""
AI Project Audit Context Generator

A strictly static analysis tool to map Python/Flask project architecture,
dependencies, and structure for incremental AI code auditing.

Core Principles:
- NEVER execute or import project code.
- NEVER guess. Distinguish between CONFIRMED, OBSERVED, and UNRESOLVED.
- Context-aware secret redaction.
- Robust and graceful error handling.
"""

import ast
import os
import re
import sys
import hashlib
import subprocess
import argparse
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Set, Tuple, Optional, Any

# --- CONFIGURATION ---

EXCLUDED_DIRS = {
    ".git", ".venv", "venv", "env", "__pycache__", ".pytest_cache",
    ".mypy_cache", ".ruff_cache", "node_modules", "dist", "build",
    "htmlcov", ".idea", ".vscode", "logs", "uploads", "_AI_AUDIT_CONTEXT"
}

EXCLUDED_FILES = {".env", ".env.local", ".env.production", ".env.staging"}

EXCLUDED_EXTENSIONS = {".pyc", ".pyo", ".so", ".dll", ".exe"}

DEFAULT_LAYERS = {
    "domain": "Domain",
    "application": "Application",
    "infrastructure": "Infrastructure",
    "interfaces": "Interfaces"
}

SECRET_PATTERNS = [
    re.compile(r"""(SECRET_KEY|API_KEY|ACCESS_TOKEN|AUTH_TOKEN|PASSWORD|DB_PASSWORD|DATABASE_URL|PRIVATE_KEY|CLIENT_SECRET|AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY)\s*=\s*['"](.*?)['"]""", re.IGNORECASE),
    re.compile(r"""(SECRET_KEY|API_KEY|ACCESS_TOKEN|AUTH_TOKEN|PASSWORD|DB_PASSWORD|DATABASE_URL|PRIVATE_KEY|CLIENT_SECRET|AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY)\s*=\s+(\S+)""", re.IGNORECASE)
]

RANKING_THRESHOLDS = {"CRITICAL": 80, "HIGH": 50, "MEDIUM": 20, "LOW": 0}

OUTPUT_DIR = "_AI_AUDIT_CONTEXT"

# --- DATA STRUCTURES ---

@dataclass
class FunctionInfo:
    name: str
    signature: str
    decorators: List[str] = field(default_factory=list)
    docstring: Optional[str] = None
    is_async: bool = False

@dataclass
class ClassInfo:
    name: str
    bases: List[str]
    decorators: List[str] = field(default_factory=list)
    methods: List[FunctionInfo] = field(default_factory=list)
    docstring: Optional[str] = None
    is_sqlalchemy_model: bool = False
    confidence: str = "CONFIRMED"

@dataclass
class RouteInfo:
    path: str
    methods: List[str]
    function: str
    blueprint: Optional[str]
    decorators: List[str]
    file: str
    signature: str
    confidence: str = "CONFIRMED"

@dataclass
class FileInfo:
    path: str
    language: str
    lines: int
    size: int
    sha256: str
    section: str
    classes: List[ClassInfo] = field(default_factory=list)
    functions: List[FunctionInfo] = field(default_factory=list)
    imports: List[str] = field(default_factory=list)
    internal_deps: Set[str] = field(default_factory=set)
    external_deps: Set[str] = field(default_factory=set)
    routes: List[RouteInfo] = field(default_factory=list)
    models: List[ClassInfo] = field(default_factory=list)
    score: int = 0
    rank: str = "LOW"
    rank_reasons: List[str] = field(default_factory=list)
    parse_error: Optional[str] = None
    secrets_redacted: int = 0

# --- CORE ANALYZERS ---

class SecurityFilter:
    """Context-aware secret redaction."""
    @staticmethod
    def redact_line(line: str) -> Tuple[str, bool]:
        # Ignore def arguments or class assignments without string literals/right side
        if re.match(r'^\s*(def|class)\s+', line):
            return line, False
            
        redacted = False
        for pattern in SECRET_PATTERNS:
            match = pattern.search(line)
            if match:
                # Ensure it's an assignment (contains '=' before the value)
                # The regex already matches the variable name and the value.
                # match.start(2) and match.end(2) point to the value part.
                prefix = line[:match.start(2)]
                suffix = line[match.end(2):]
                line = f"{prefix}[POTENTIAL SECRET REDACTED]{suffix}"
                redacted = True
                break
        return line, redacted

    @staticmethod
    def redact_source(source: str) -> Tuple[str, int]:
        lines = source.splitlines()
        redacted_count = 0
        out_lines = []
        for line in lines:
            new_line, was_redacted = SecurityFilter.redact_line(line)
            out_lines.append(new_line)
            if was_redacted:
                redacted_count += 1
        return "\n".join(out_lines), redacted_count


class PythonAnalyzer:
    """Strictly static AST analysis for Python files."""
    @staticmethod
    def analyze(file_path: Path, project_root: Path) -> FileInfo:
        rel_path = str(file_path.relative_to(project_root))
        source = file_path.read_text(encoding='utf-8', errors='replace')
        lines = source.splitlines()
        sha256 = hashlib.sha256(source.encode('utf-8')).hexdigest()
        
        # Initial redaction count (we analyze original, but track redactions for manifest)
        _, redacted_count = SecurityFilter.redact_source(source)

        info = FileInfo(
            path=rel_path,
            language="Python",
            lines=len(lines),
            size=file_path.stat().st_size,
            sha256=sha256,
            section=rel_path.split(os.sep)[0] if os.sep in rel_path else "root",
            secrets_redacted=redacted_count
        )

        try:
            tree = ast.parse(source)
        except SyntaxError as e:
            info.parse_error = f"SyntaxError: {e.msg} (line {e.lineno})"
            return info

        # Extract imports from the whole tree (including inside functions)
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                PythonAnalyzer._extract_imports(node, info, project_root, rel_path)
                
        # Extract only module-level classes and functions to avoid AST body type issues
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                PythonAnalyzer._extract_class(node, info, rel_path)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                PythonAnalyzer._extract_function(node, info, is_module_level=True)

        return info

    @staticmethod
    def _extract_imports(node: ast.AST, info: FileInfo, root: Path, file_rel_path: str):
        if isinstance(node, ast.Import):
            for alias in node.names:
                info.imports.append(f"import {alias.name}")
                info.external_deps.add(alias.name.split('.')[0])
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ''
            names = ", ".join(alias.name for alias in node.names)
            info.imports.append(f"from {'.' * node.level}{module} import {names}")
            
            if node.level > 0:
                # Resolve relative import statically
                current_package = Path(file_rel_path).parent
                resolved_path = current_package
                for _ in range(node.level - 1):
                    resolved_path = resolved_path.parent
                    
                resolved_module = str(resolved_path).replace(os.sep, '.')
                if module:
                    resolved_module += f".{module}"
                    
                info.internal_deps.add(resolved_module)
            else:
                # Absolute import
                top_level = module.split('.')[0]
                if (root / top_level).is_dir() or (root / f"{top_level}.py").is_file():
                    info.internal_deps.add(module)
                else:
                    info.external_deps.add(top_level)

    @staticmethod
    def _extract_class(node: ast.ClassDef, info: FileInfo, file_rel_path: str):
        bases = [PythonAnalyzer._get_name(b) for b in node.bases]
        decorators = [PythonAnalyzer._get_decorator_name(d) for d in node.decorator_list]
        docstring = ast.get_docstring(node)
        
        cls_info = ClassInfo(name=node.name, bases=bases, decorators=decorators, docstring=docstring)
        
        # SQLAlchemy check (Strict)
        if any(b in bases for b in ['db.Model', 'Base']):
            cls_info.is_sqlalchemy_model = True
            cls_info.confidence = "CONFIRMED"
            info.models.append(cls_info)
        elif any('Model' in b or 'Base' in b for b in bases):
            cls_info.is_sqlalchemy_model = True
            cls_info.confidence = "OBSERVED"
            info.models.append(cls_info)
        else:
            cls_info.is_sqlalchemy_model = False

        # Methods
        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func = PythonAnalyzer._extract_function(item, info, is_module_level=False)
                cls_info.methods.append(func)
                
                # Route detection
                PythonAnalyzer._extract_routes(item, info, file_rel_path)

        info.classes.append(cls_info)

    @staticmethod
    def _extract_function(node: ast.AST, info: FileInfo, is_module_level: bool) -> FunctionInfo:
        decorators = [PythonAnalyzer._get_decorator_name(d) for d in node.decorator_list]
        docstring = ast.get_docstring(node)
        signature = PythonAnalyzer._get_signature(node)
        is_async = isinstance(node, ast.AsyncFunctionDef)
        
        func_info = FunctionInfo(name=node.name, signature=signature, decorators=decorators, docstring=docstring, is_async=is_async)
        
        if is_module_level:
            info.functions.append(func_info)
            # Check for module-level routes
            PythonAnalyzer._extract_routes(node, info, info.path)
            
        return func_info

    @staticmethod
    def _extract_routes(node: ast.FunctionDef, info: FileInfo, file_rel_path: str):
        all_decorators = [PythonAnalyzer._get_decorator_name(d) for d in node.decorator_list]
        
        for dec_node in node.decorator_list:
            if isinstance(dec_node, ast.Call) and isinstance(dec_node.func, ast.Attribute):
                func_attr = dec_node.func
                if func_attr.attr in ('route', 'get', 'post', 'put', 'delete', 'patch'):
                    blueprint_name = PythonAnalyzer._get_name(func_attr.value)
                    method_type = func_attr.attr
                    
                    path = "[UNRESOLVED DYNAMIC ROUTE]"
                    methods = []
                    
                    # Extract path directly from AST argument
                    if dec_node.args and isinstance(dec_node.args[0], ast.Constant) and isinstance(dec_node.args[0].value, str):
                        path = dec_node.args[0].value
                        
                    # Extract methods directly from AST keyword
                    if method_type == 'route':
                        for kw in dec_node.keywords:
                            if kw.arg == 'methods' and isinstance(kw.value, ast.List):
                                methods = [
                                    elt.value for elt in kw.value.elts 
                                    if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
                                ]
                        if not methods:
                            methods = ["GET"] # Default for route
                    else:
                        methods = [method_type.upper()]
                        
                    signature = PythonAnalyzer._get_signature(node)
                    
                    route_info = RouteInfo(
                        path=path,
                        methods=methods if methods else ["GET"],
                        function=node.name,
                        blueprint=blueprint_name if blueprint_name != 'app' else None,
                        decorators=all_decorators,
                        file=file_rel_path,
                        signature=signature,
                        confidence="CONFIRMED" if path != "[UNRESOLVED DYNAMIC ROUTE]" else "OBSERVED"
                    )
                    info.routes.append(route_info)

    @staticmethod
    def _get_name(node: ast.AST) -> str:
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            return f"{PythonAnalyzer._get_name(node.value)}.{node.attr}"
        elif isinstance(node, ast.Constant):
            return str(node.value)
        elif isinstance(node, ast.List):
            return f"[{', '.join(PythonAnalyzer._get_name(e) for e in node.elts)}]"
        return "[UNRESOLVED]"

    @staticmethod
    def _get_decorator_name(node: ast.AST) -> str:
        if isinstance(node, ast.Call):
            args_str = ', '.join(PythonAnalyzer._get_name(arg) for arg in node.args)
            kwargs_str = ', '.join(f"{kw.arg}={PythonAnalyzer._get_name(kw.value)}" for kw in node.keywords)
            all_args = ', '.join(filter(None, [args_str, kwargs_str]))
            return f"{PythonAnalyzer._get_name(node.func)}({all_args})"
        return PythonAnalyzer._get_name(node)

    @staticmethod
    def _get_signature(node: ast.FunctionDef) -> str:
        args = []
        for arg in node.args.args:
            arg_str = arg.arg
            if arg.annotation:
                arg_str += f": {PythonAnalyzer._get_name(arg.annotation)}"
            args.append(arg_str)
            
        if node.args.vararg:
            arg_str = f"*{node.args.vararg.arg}"
            if node.args.vararg.annotation:
                arg_str += f": {PythonAnalyzer._get_name(node.args.vararg.annotation)}"
            args.append(arg_str)
            
        if node.args.kwarg:
            arg_str = f"**{node.args.kwarg.arg}"
            if node.args.kwarg.annotation:
                arg_str += f": {PythonAnalyzer._get_name(node.args.kwarg.annotation)}"
            args.append(arg_str)
        
        return_prefix = "async " if isinstance(node, ast.AsyncFunctionDef) else ""
        return_suffix = ""
        if node.returns:
            return_suffix = f" -> {PythonAnalyzer._get_name(node.returns)}"
            
        return f"{return_prefix}def {node.name}({', '.join(args)}){return_suffix}"


class TemplateAnalyzer:
    """Regex-based structural analysis for Jinja2 templates."""
    @staticmethod
    def analyze(file_path: Path, project_root: Path) -> FileInfo:
        rel_path = str(file_path.relative_to(project_root))
        source = file_path.read_text(encoding='utf-8', errors='replace')
        lines = source.splitlines()
        sha256 = hashlib.sha256(source.encode('utf-8')).hexdigest()

        info = FileInfo(
            path=rel_path,
            language="HTML/Jinja2",
            lines=len(lines),
            size=file_path.stat().st_size,
            sha256=sha256,
            section=rel_path.split(os.sep)[0] if os.sep in rel_path else "root"
        )

        try:
            # Extends
            extends = re.findall(r'\{%\s*extends\s*["\'](.*?)["\']\s*%\}', source)
            # Includes
            includes = re.findall(r'\{%\s*include\s*["\'](.*?)["\']\s*%\}', source)
            # Blocks
            blocks = re.findall(r'\{%\s*block\s+(\w+)\s*%\}', source)
            # Routes
            routes = re.findall(r'\{\{\s*url_for\(["\'](.*?)["\']', source)
            
            # Store as pseudo-imports for dependency tracking
            info.imports.extend([f"extends: {e}" for e in extends])
            info.imports.extend([f"includes: {i}" for i in includes])
            info.internal_deps.update(includes)
            info.internal_deps.update(extends)
            
            # Pseudo-routes for graph
            info.routes = [RouteInfo(path=r, methods=[], function="", blueprint=None, decorators=[], file=rel_path, signature="", confidence="OBSERVED") for r in routes]

        except Exception as e:
            info.parse_error = f"JINJA PARSE ERROR: {str(e)}"

        return info

# --- GRAPH & RANKING ---

class DependencyMapper:
    @staticmethod
    def build_dependency_map(files: Dict[str, FileInfo]) -> Dict[str, Set[str]]:
        graph = {}
        for path, info in files.items():
            module_path = path.replace(os.sep, '.').replace('.py', '').replace('.html', '')
            graph[module_path] = info.internal_deps
        return graph

    @staticmethod
    def detect_violations(files: Dict[str, FileInfo], layers: Dict[str, str]) -> List[Dict[str, Any]]:
        violations = []
        layer_hierarchy = {"Interfaces": 0, "Application": 1, "Domain": 2, "Infrastructure": 3}
        
        for path, info in files.items():
            parts = path.split(os.sep)
            if len(parts) < 2: continue
            
            source_layer_name = layers.get(parts[0])
            if not source_layer_name or source_layer_name not in layer_hierarchy: continue
            
            for dep in info.internal_deps:
                # Check if dep is a folder in layers
                dep_top_level = dep.split('.')[0]
                target_layer_name = layers.get(dep_top_level)
                
                if target_layer_name and target_layer_name in layer_hierarchy:
                    # Strict DDD layering rules check (e.g., Domain shouldn't depend on Infra or App)
                    if source_layer_name == "Domain" and target_layer_name in ["Infrastructure", "Application", "Interfaces"]:
                        violations.append({
                            "file": path,
                            "imports": dep,
                            "violation": f"{source_layer_name} -> {target_layer_name}",
                            "confidence": "CONFIRMED"
                        })
        return violations

class FileRanker:
    @staticmethod
    def rank(files: Dict[str, FileInfo]):
        # Calculate dependents (how many files import this file)
        dependents_map = {path: 0 for path in files.keys()}
        for info in files.values():
            for dep in info.internal_deps:
                # Rough match
                for path in files.keys():
                    if path.replace(os.sep, '.').startswith(dep):
                        dependents_map[path] += 1
                        break

        for path, info in files.items():
            score = 0
            reasons = []
            
            # Dependents
            dep_count = dependents_map.get(path, 0)
            score += dep_count * 5
            if dep_count > 2: reasons.append(f"{dep_count} internal dependents")

            # Internal deps
            int_dep_count = len(info.internal_deps)
            score += int_dep_count * 2

            # Routes
            if info.routes:
                score += 15
                reasons.append("Flask route")
                
            # Models
            if info.models:
                score += 15
                reasons.append("Database model")
                
            # Classes / Functions
            if info.classes:
                score += len(info.classes) * 3
                reasons.append("Contains business class")
                
            # Section priority
            if info.section == 'domain':
                score += 20
                reasons.append("Domain core")
            elif info.section == 'application':
                score += 10
                reasons.append("Application service")

            info.score = score
            info.rank_reasons = reasons
            
            if score >= RANKING_THRESHOLDS["CRITICAL"]: info.rank = "CRITICAL"
            elif score >= RANKING_THRESHOLDS["HIGH"]: info.rank = "HIGH"
            elif score >= RANKING_THRESHOLDS["MEDIUM"]: info.rank = "MEDIUM"
            else: info.rank = "LOW"

# --- RENDERERS ---

class MarkdownRenderer:
    @staticmethod
    def render_project_structure(files: Dict[str, FileInfo]) -> str:
        md = ["# Project Structure\n"]
        
        # Group files by directory tree
        dir_tree = {}
        for path in files.keys():
            parts = Path(path).parts
            current = dir_tree
            for part in parts:
                if part not in current:
                    current[part] = {}
                current = current[part]
                
        def render_tree(tree, indent=0):
            lines = []
            prefix = "    " * indent
            items = sorted(tree.items())
            for i, (name, children) in enumerate(items):
                connector = "└──" if i == len(items) - 1 else "├──"
                if children:
                    lines.append(f"{prefix}{connector} {name}/")
                    lines.extend(render_tree(children, indent + 1))
                else:
                    lines.append(f"{prefix}{connector} {name}")
            return lines
            
        md.append("```text")
        md.append("project_root/")
        md.extend(render_tree(dir_tree, 1))
        md.append("```\n")
        
        md.append("## File Details\n")
        for path, info in files.items():
            md.append(f"### {path}\n")
            md.append(f"- **Type:** {info.language}")
            md.append(f"- **Lines:** {info.lines}")
            md.append(f"- **Classes:** {len(info.classes)}")
            md.append(f"- **Functions:** {len(info.functions)}")
            md.append(f"- **Internal dependencies:** {', '.join(info.internal_deps) if info.internal_deps else 'None'}")
            md.append(f"- **External dependencies:** {', '.join(info.external_deps) if info.external_deps else 'None'}\n")
            
        return "\n".join(md)

    @staticmethod
    def render_summaries(files: Dict[str, FileInfo]) -> Dict[str, str]:
        sections = {}
        # Group by section
        section_files = {}
        for path, info in files.items():
            sec = info.section
            if sec not in section_files: section_files[sec] = []
            section_files[sec].append(info)
            
        for sec, infos in section_files.items():
            md = [f"# {sec.capitalize()} Summary\n"]
            for info in infos:
                md.append(f"## FILE: {info.path}\n")
                md.append(f"**LINES:** {info.lines}  \n")
                md.append("### IMPORTS\n```python")
                md.extend(info.imports)
                md.append("```\n")
                
                if info.models:
                    md.append("### MODELS\n")
                    for m in info.models:
                        md.append(f"**CLASS:** {m.name} (Confidence: {m.confidence})\n")
                        md.append(f"- Base: {', '.join(m.bases)}\n")
                
                if info.classes:
                    md.append("### CLASSES\n")
                    for cls in info.classes:
                        md.append(f"#### CLASS: {cls.name}\n")
                        md.append(f"- **Base Classes:** {', '.join(cls.bases)}")
                        md.append(f"- **Decorators:** {', '.join(cls.decorators) if cls.decorators else 'None'}")
                        if cls.docstring: md.append(f"- **Docstring:** \"{cls.docstring}\"\n")
                        
                        for meth in cls.methods:
                            md.append(f"**METHOD:** `{meth.signature}`")
                            if meth.decorators: md.append(f"  - Decorators: {', '.join(meth.decorators)}")
                
                if info.functions:
                    md.append("### FUNCTIONS\n")
                    for func in info.functions:
                        md.append(f"#### FUNCTION: {func.name}\n")
                        md.append(f"```python\n{func.signature}\n```\n")
                        
                if info.routes:
                    md.append("### ROUTES\n")
                    for r in info.routes:
                        md.append(f"- **Path:** `{r.path}` | **Methods:** {r.methods} | **Function:** `{r.function}` | Confidence: {r.confidence}\n")
                        
            sections[sec] = "\n".join(md)
        return sections

    @staticmethod
    def render_dependency_graph(files: Dict[str, FileInfo]) -> str:
        md = ["# Dependency Graph\n"]
        for path, info in files.items():
            module = path.replace(os.sep, '.').replace('.py', '').replace('.html', '')
            if info.internal_deps:
                md.append(f"{module}")
                for dep in info.internal_deps:
                    md.append(f"    ├── {dep}")
        return "\n".join(md)

    @staticmethod
    def render_architecture_map(files: Dict[str, FileInfo], layers: Dict[str, str], violations: List[Dict[str, Any]]) -> str:
        md = ["# Architecture Map\n"]
        md.append("```text")
        md.append("Interfaces (web/API)")
        md.append("    ↓")
        md.append("Application (Services)")
        md.append("    ↓")
        md.append("Domain (Core Logic)")
        md.append("\nInfrastructure (DB/External)")
        md.append("    ↑")
        md.append("Application (Services)\n")
        md.append("```\n")
        
        if violations:
            md.append("## ARCHITECTURAL OBSERVATIONS\n")
            for v in violations:
                md.append(f"**Violation:** `{v['file']}` imports `{v['imports']}` directly.")
                md.append(f"- Type: {v['violation']} boundary violation")
                md.append(f"- Confidence: {v['confidence']}\n")
        return "\n".join(md)

    @staticmethod
    def render_manifest(files: Dict[str, FileInfo]) -> str:
        md = ["# File Manifest\n"]
        md.append("| Path | Type | Size | Lines | Language | SHA256 | Section | Rank |")
        md.append("|---|---|---|---|---|---|---|---|")
        for path, info in files.items():
            size_kb = f"{info.size / 1024:.1f} KB"
            md.append(f"| {path} | {info.language} | {size_kb} | {info.lines} | {info.language} | `{info.sha256[:8]}...` | {info.section} | {info.rank} |")
        return "\n".join(md)

    @staticmethod
    def render_ranking(files: Dict[str, FileInfo]) -> str:
        md = ["# File Ranking\n"]
        for rank_name in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            ranked_files = [info for info in files.values() if info.rank == rank_name]
            if ranked_files:
                md.append(f"## {rank_name}\n")
                for info in ranked_files:
                    md.append(f"### {info.path}\n")
                    md.append(f"- **Score:** {info.score}")
                    md.append(f"- **Reasons:** {', '.join(info.rank_reasons) if info.rank_reasons else 'Low impact'}\n")
        return "\n".join(md)

    @staticmethod
    def render_git_context(root: Path) -> str:
        md = ["# Git Context\n"]
        if not (root / ".git").is_dir():
            md.append("[GIT REPOSITORY NOT FOUND]\n")
            return "\n".join(md)
            
        def run_git(cmd: List[str]) -> str:
            try:
                return subprocess.run(cmd, cwd=root, capture_output=True, text=True, check=True).stdout.strip()
            except Exception:
                return "[ERROR RUNNING GIT]"
                
        md.append(f"**Branch:** {run_git(['git', 'rev-parse', '--abbrev-ref', 'HEAD'])}")
        md.append(f"**Latest Commit:** {run_git(['git', 'log', '-1', '--oneline'])}\n")
        md.append("### Status\n```text")
        md.append(run_git(['git', 'status', '--short']))
        md.append("```\n")
        return "\n".join(md)

# --- MAIN ORCHESTRATOR ---

def main():
    parser = argparse.ArgumentParser(description="AI Project Audit Context Generator")
    parser.add_argument("--full", action="store_true", help="Copy full source files (redacted)")
    parser.add_argument("--summary", action="store_true", help="Generate summaries (default: True)")
    parser.add_argument("--layer", action="append", help="Override layer mapping, e.g., domain=Domain")
    args = parser.parse_args()

    project_root = Path.cwd()
    output_root = project_root / OUTPUT_DIR
    
    # Clean previous run
    if output_root.exists():
        for f in output_root.glob('*'):
            if f.is_file(): f.unlink()
            elif f.is_dir():
                for sub in f.rglob('*'):
                    if sub.is_file(): sub.unlink()
                for sub in reversed(list(f.glob('*'))):
                    if sub.is_dir(): sub.rmdir()
                f.rmdir()

    # Setup dirs
    (output_root / "summaries").mkdir(parents=True, exist_ok=True)
    full_source_dir = output_root / "full_source"

    layers = DEFAULT_LAYERS.copy()
    if args.layer:
        for l_map in args.layer:
            k, v = l_map.split('=')
            layers[k] = v

    print("Discovering files...")
    files: Dict[str, FileInfo] = {}
    
    for root, dirs, filenames in os.walk(project_root):
        # Exclude dirs
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS and not (Path(root) / d).name.startswith('.')]
        
        for filename in filenames:
            filepath = Path(root) / filename
            rel_path = str(filepath.relative_to(project_root))
            
            if any(rel_path.startswith(ex) for ex in EXCLUDED_FILES): continue
            if any(filepath.suffix == ext for ext in EXCLUDED_EXTENSIONS): continue
            if filepath.parent.name == OUTPUT_DIR: continue

            if filepath.suffix == '.py':
                files[rel_path] = PythonAnalyzer.analyze(filepath, project_root)
            elif filepath.suffix in ['.html', '.htm', '.jinja2']:
                files[rel_path] = TemplateAnalyzer.analyze(filepath, project_root)

    print(f"Discovered {len(files)} processable files.")

    print("Building dependencies and ranking...")
    FileRanker.rank(files)
    violations = DependencyMapper.detect_violations(files, layers)

    print("Generating Markdown outputs...")
    (output_root / "01_PROJECT_STRUCTURE.md").write_text(MarkdownRenderer.render_project_structure(files), encoding='utf-8')
    (output_root / "02_ARCHITECTURE_MAP.md").write_text(MarkdownRenderer.render_architecture_map(files, layers, violations), encoding='utf-8')
    (output_root / "03_DEPENDENCY_GRAPH.md").write_text(MarkdownRenderer.render_dependency_graph(files), encoding='utf-8')
    (output_root / "04_FILE_MANIFEST.md").write_text(MarkdownRenderer.render_manifest(files), encoding='utf-8')
    (output_root / "05_FILE_RANKING.md").write_text(MarkdownRenderer.render_ranking(files), encoding='utf-8')
    (output_root / "06_GIT_CONTEXT.md").write_text(MarkdownRenderer.render_git_context(project_root), encoding='utf-8')

    summaries = MarkdownRenderer.render_summaries(files)
    for sec, content in summaries.items():
        (output_root / "summaries" / f"{sec.upper()}_SUMMARY.md").write_text(content, encoding='utf-8')

    if args.full:
        print("Copying full source (with secret redaction)...")
        full_source_dir.mkdir(parents=True, exist_ok=True)
        for rel_path, info in files.items():
            if info.language == "Python":
                orig_path = project_root / rel_path
                dest_path = full_source_dir / rel_path
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                
                source = orig_path.read_text(encoding='utf-8', errors='replace')
                safe_source, _ = SecurityFilter.redact_source(source)
                dest_path.write_text(safe_source, encoding='utf-8')

    print("Generation Complete.")
    print("\n--- GENERATION REPORT ---")
    py_files = [i for i in files.values() if i.language == "Python"]
    html_files = [i for i in files.values() if i.language == "HTML/Jinja2"]
    
    print(f"Files discovered: {len(files)}")
    print(f"Python files: {len(py_files)}")
    print(f"HTML/Templates: {len(html_files)}")
    print(f"Classes: {sum(len(i.classes) for i in py_files)}")
    print(f"Functions: {sum(len(i.functions) for i in py_files)}")
    print(f"Routes: {sum(len(i.routes) for i in files.values())}")
    print(f"Database models: {sum(len(i.models) for i in py_files)}")
    print(f"Parse errors: {len([i for i in py_files if i.parse_error])}")
    print(f"Secrets redacted: {sum(i.secrets_redacted for i in files.values())}")

if __name__ == "__main__":
    main()