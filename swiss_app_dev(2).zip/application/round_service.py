"""
Round and pairing use-cases.
FIDE Dutch Swiss compliant with Incremental Updates and Manual Adjustments.
"""
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple

from app.extensions import db
from infrastructure.repositories import (
    ParticipantRepository,
    RoundRepository,
    PairingRepository,
    ManualPairingRepository,
)
from infrastructure.db_models import (
    RoundModel,
    PairingModel,
    ByeRequestModel,
    ManualPairingModel,
    TournamentParticipantModel,
)

from domain.pairing import SwissEngine, PlayerData
from domain.pairing.models import compute_color

# ── Custom Exceptions ──
class ManualPairingError(ValueError): pass
class SwapError(ValueError): pass

class RoundService:
    # ═════════════════════════════════════════════════════════
    #  1. Round Lifecycle (Core Logic)
    # ═════════════════════════════════════════════════════════

    @staticmethod
    def create_next_round(tournament) -> RoundModel:
        last_round = RoundRepository.get_last(tournament.id)
        if last_round and last_round.status not in ["finished", "pending"]:
            raise ValueError("Cannot create new round. Previous round is not finished.")

        next_number = (last_round.round_number + 1) if last_round else 1
        if next_number > tournament.total_rounds:
            raise ValueError("Tournament has reached the maximum number of rounds.")

        if next_number == 1:
            RoundService._initialize_pairing_numbers(tournament.id)

        active_participants = ParticipantRepository.get_active(tournament.id)
        if len(active_participants) < 2:
            raise ValueError("Not enough active players to create a round.")

        bye_requests = ByeRequestModel.query.filter_by(
            tournament_id=tournament.id, for_round=next_number
        ).all()
        bye_participant_ids = {br.participant_id: br.bye_type for br in bye_requests}

        manual_pairings = ManualPairingRepository.get_for_round(tournament.id, next_number)
        locked_pairs = [(mp.white_participant_id, mp.black_participant_id) for mp in manual_pairings]

        pairing_players = []
        for p in active_participants:
            if p.id in bye_participant_ids: continue
            
            pairing_players.append(PlayerData(
                id=p.id,
                pairing_no=p.pairing_no or p.start_number,
                rating=p.rating,
                points=p.points or 0.0,
                color_hist=p.color_history or "",
                float_hist=p.float_history or "",
                received_bye=p.received_bye or False,
                opponents=frozenset(RoundService._get_opponent_ids(p.id, tournament.id))
            ))

        engine = SwissEngine(
            players=pairing_players,
            round_number=next_number,
            locked_pairs=locked_pairs,
        )
        result = engine.generate()

        new_round = RoundModel(tournament_id=tournament.id, round_number=next_number, status="ongoing")
        db.session.add(new_round)
        db.session.flush()

        pairing_models = []
        for card in result.pairings:
            pm = PairingModel(
                round_id=new_round.id,
                tournament_id=tournament.id,
                board_number=card.board,
                white_participant_id=card.white_id,
                black_participant_id=card.black_id,
                result="bye" if card.is_bye else "",
                white_float=card.white_float,
                black_float=card.black_float
            )
            pairing_models.append(pm)

        board = len(pairing_models) + 1
        for pid, btype in bye_participant_ids.items():
            pm = PairingModel(
                round_id=new_round.id, tournament_id=tournament.id, board_number=board,
                white_participant_id=pid, black_participant_id=None, result=btype,
                white_float="", black_float=""
            )
            pairing_models.append(pm)
            board += 1

        PairingRepository.save_all(pairing_models)
        
        for br in bye_requests: db.session.delete(br)
        ManualPairingRepository.delete_all_for_round(tournament.id, next_number)

        tournament.current_round = next_number
        tournament.status = "ongoing"

        if next_number == 1:
            auto_pair_index = 0
            for pm in pairing_models:
                if not pm.black_participant_id:
                    continue
                is_manual = (pm.white_participant_id, pm.black_participant_id) in locked_pairs or \
                            (pm.black_participant_id, pm.white_participant_id) in locked_pairs
                
                if not is_manual:
                    if auto_pair_index % 2 == 1:
                        pm.white_participant_id, pm.black_participant_id = pm.black_participant_id, pm.white_participant_id
                    auto_pair_index += 1

        db.session.commit()
        return new_round

    @staticmethod
    def finish_round(round_obj, tournament) -> None:
        pairings = PairingRepository.get_all_for_round(round_obj.id)

        for p in pairings:
            if p.result == "" and p.black_participant_id is not None:
                raise ValueError(f"Board {p.board_number} result is missing.")
        
        for p in pairings:
            RoundService._update_participant_stats_incremental(p)

        round_obj.status = "finished"
        round_obj.finished_at = datetime.utcnow()

        if round_obj.round_number >= tournament.total_rounds:
            tournament.status = "finished"

        db.session.commit()

    @staticmethod
    def save_results(round_obj, form_data) -> None:
        pairings = PairingRepository.get_all_for_round(round_obj.id)
        valid_results = {"1-0", "0-1", "1/2", "+/-", "-/+", "+/+", ""}

        for pairing in pairings:
            if pairing.result in {"bye", "half-bye", "zero-bye"}: continue
            
            key = f"result_{pairing.id}"
            new_result = form_data.get(key, "").strip()
            
            if new_result in valid_results:
                pairing.result = new_result

        db.session.commit()

    # ═════════════════════════════════════════════════════════
    #  2. Manual Adjustments (Swaps)
    # ═════════════════════════════════════════════════════════

    @staticmethod
    def swap_colors_in_board(round_obj, board: int) -> None:
        if round_obj.status == "finished": raise SwapError("Cannot edit a finished round.")
        
        pairings = PairingRepository.get_all_for_round(round_obj.id)
        pairing = next((p for p in pairings if p.board_number == board), None)

        if not pairing or not pairing.black_participant_id: 
            raise SwapError("Board not found or is a Bye.")
        
        w_id, b_id = pairing.white_participant_id, pairing.black_participant_id
        
        RoundService._validate_color_swap(b_id, "w", round_obj.tournament_id)
        RoundService._validate_color_swap(w_id, "b", round_obj.tournament_id)

        pairing.white_participant_id, pairing.black_participant_id = b_id, w_id
        pairing.white_float, pairing.black_float = pairing.black_float, pairing.white_float

        flip = {"1-0": "0-1", "0-1": "1-0", "+/-": "-/+", "-/+": "+/-"}
        if pairing.result in flip: pairing.result = flip[pairing.result]

        db.session.commit()

    @staticmethod
    def swap_players_between_boards(round_obj, board1, pos1, board2, pos2) -> None:
        if round_obj.status == "finished": raise SwapError("Cannot edit a finished round.")

        pairings = PairingRepository.get_all_for_round(round_obj.id)
        p1 = next((p for p in pairings if p.board_number == board1), None)
        p2 = next((p for p in pairings if p.board_number == board2), None)
        
        if not p1 or not p2 or not p1.black_participant_id or not p2.black_participant_id:
            raise SwapError("Selected boards must be valid pairings (not Byes).")

        pid1 = p1.white_participant_id if pos1 == "white" else p1.black_participant_id
        float1 = p1.white_float if pos1 == "white" else p1.black_float

        pid2 = p2.white_participant_id if pos2 == "white" else p2.black_participant_id
        float2 = p2.white_float if pos2 == "white" else p2.black_float
        
        opp1 = p1.black_participant_id if pos1 == "white" else p1.white_participant_id
        opp2 = p2.black_participant_id if pos2 == "white" else p2.white_participant_id
        
        if RoundService._have_played(pid1, opp2, round_obj.tournament_id) or \
           RoundService._have_played(pid2, opp1, round_obj.tournament_id):
            raise SwapError("Players have already faced the new opponents.")

        RoundService._validate_color_swap(pid1, ("w" if pos2 == "white" else "b"), round_obj.tournament_id)
        RoundService._validate_color_swap(pid2, ("w" if pos1 == "white" else "b"), round_obj.tournament_id)

        if pos1 == "white":
            p1.white_participant_id, p1.white_float = pid2, float2
        else:
            p1.black_participant_id, p1.black_float = pid2, float2
            
        if pos2 == "white":
            p2.white_participant_id, p2.white_float = pid1, float1
        else:
            p2.black_participant_id, p2.black_float = pid1, float1
            
        db.session.commit()

    # ═════════════════════════════════════════════════════════
    #  3. Pre-Pairing Manual Controls
    # ═════════════════════════════════════════════════════════

    @staticmethod
    def add_manual_pairing(tournament, round_number, white_id, black_id):
        if white_id == black_id:
            raise ManualPairingError("یک بازیکن نمی‌تواند با خودش بازی کند.")
        
        bye_exists = ByeRequestModel.query.filter(
            ByeRequestModel.tournament_id == tournament.id,
            ByeRequestModel.for_round == round_number,
            ByeRequestModel.participant_id.in_([white_id, black_id])
        ).first()
        if bye_exists:
            raise ManualPairingError("یکی از این بازیکنان برای این دور استراحت (Bye) دارد.")
        
        if RoundRepository.get_by_number(tournament.id, round_number):
            raise ManualPairingError("Round has already been generated.")
        
        if RoundService._have_played(white_id, black_id, tournament.id):
            raise ManualPairingError("Players have already played each other.")

        RoundService._validate_color_swap(white_id, "w", tournament.id)
        RoundService._validate_color_swap(black_id, "b", tournament.id)

        mp = ManualPairingModel(tournament_id=tournament.id, round_number=round_number,
                                white_participant_id=white_id, black_participant_id=black_id)
        db.session.add(mp)
        db.session.commit()

    @staticmethod
    def add_manual_bye(tournament, participant_id: int, bye_type: str) -> None:
        next_round = (tournament.current_round + 1)
        mp_exists = ManualPairingModel.query.filter(
            ManualPairingModel.tournament_id == tournament.id,
            ManualPairingModel.round_number == next_round,
            (ManualPairingModel.white_participant_id == participant_id) | (ManualPairingModel.black_participant_id == participant_id)
        ).first()
        if mp_exists:
            raise ValueError("این بازیکن در قرعه‌کشی دستی قفل شده است و نمی‌تواند همزمان استراحت بگیرد.")
        bye_req = ByeRequestModel(tournament_id=tournament.id, participant_id=participant_id,
                                  bye_type=bye_type, for_round=next_round)
        db.session.add(bye_req)
        db.session.commit()

    # ═════════════════════════════════════════════════════════
    #  4. Maintenance & Deletion
    # ═════════════════════════════════════════════════════════

    @staticmethod
    def delete_round(round_obj, tournament):
        db.session.delete(round_obj)
        tournament.current_round = max(0, round_obj.round_number - 1)
        db.session.commit()
        RoundService._full_refresh_stats(tournament.id)

    @staticmethod
    def _full_refresh_stats(tournament_id):
        participants = TournamentParticipantModel.query.filter_by(tournament_id=tournament_id).all()
        rounds = RoundModel.query.filter_by(tournament_id=tournament_id).order_by(RoundModel.round_number).all()
        
        for p in participants:
            p.points = 0.0
            p.color_history = ""
            p.float_history = ""
            p.received_bye = False
        
        for r in rounds:
            pairings = PairingModel.query.filter_by(round_id=r.id).all()
            for pr in pairings:
                RoundService._update_participant_stats_incremental(pr)
        
        db.session.commit()

    # ═════════════════════════════════════════════════════════
    #  5. Internal Utilities (Private)
    # ═════════════════════════════════════════════════════════

    @staticmethod
    def _initialize_pairing_numbers(tournament_id: int):
        participants = TournamentParticipantModel.query.filter_by(tournament_id=tournament_id).all()
        sorted_participants = sorted(participants, key=lambda p: (-(p.rating_snapshot or 0), p.start_number))
        for idx, p in enumerate(sorted_participants, start=1):
            p.pairing_no = idx
        db.session.flush()

    @staticmethod
    def _update_participant_stats_incremental(pairing: PairingModel):
        res_scores = {
            "1-0": (1.0, 0.0), "0-1": (0.0, 1.0), "1/2": (0.5, 0.5),
            "+/-": (1.0, 0.0), "-/+": (0.0, 1.0), "+/+" : (0.0, 0.0),
            "bye": (1.0, 0.0), "half-bye": (0.5, 0.0), "zero-bye": (0.0, 0.0)
        }
        w_score, b_score = res_scores.get(pairing.result, (0.0, 0.0))
        
        is_unplayed = pairing.result in ["+/-", "-/+", "+/+", "bye", "half-bye", "zero-bye"]

        if pairing.white_participant:
            wp = pairing.white_participant
            wp.points = (wp.points or 0.0) + w_score
            wp.color_history = (wp.color_history or "") + ("-" if is_unplayed else ("w" if pairing.black_participant_id else "-"))
            wp.float_history = (wp.float_history or "") + (pairing.white_float or "-")
            if pairing.result == "bye": wp.received_bye = True
        
        if pairing.black_participant:
            bp = pairing.black_participant
            bp.points = (bp.points or 0.0) + b_score
            bp.color_history = (bp.color_history or "") + ("-" if is_unplayed else "b")
            bp.float_history = (bp.float_history or "") + (pairing.black_float or "-")

    @staticmethod
    def _validate_color_swap(participant_id, new_color, tournament_id):
        p = TournamentParticipantModel.query.get(participant_id)
        state = compute_color(p.color_history or "")

        if new_color == "w" and state.last_two == "ww": raise SwapError(f"Cannot swap: Player {p.full_name} would have 3 Whites.")
        if new_color == "b" and state.last_two == "bb": raise SwapError(f"Cannot swap: Player {p.full_name} would have 3 Blacks.")

        new_bal = state.balance + (1 if new_color == "w" else -1)
        if abs(new_bal) > 2: raise SwapError(f"Cannot swap: Player {p.full_name} color balance would exceed 2.")

    @staticmethod
    def _get_opponent_ids(participant_id: int, tournament_id: int) -> Set[int]:
        p1 = db.session.query(PairingModel.black_participant_id).filter_by(tournament_id=tournament_id, white_participant_id=participant_id).all()
        p2 = db.session.query(PairingModel.white_participant_id).filter_by(tournament_id=tournament_id, black_participant_id=participant_id).all()
        return {id[0] for id in p1 if id[0]} | {id[0] for id in p2 if id[0]}

    @staticmethod
    def _have_played(p1_id, p2_id, tournament_id):
        return p2_id in RoundService._get_opponent_ids(p1_id, tournament_id)